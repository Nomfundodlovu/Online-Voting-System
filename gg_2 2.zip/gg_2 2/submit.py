import streamlit as st
import subprocess
import os

def message():
    st.title("Welcome to VoteConnect!")

    st.image("/Users/da_mac_41_/Downloads/votepc.png", caption="Thank You For Registering", width=200)
    
    st.write("🎉 Congratulations! You have successfully registered! 🎉")
    
    Home = st.button("Home")
    if Home:
        st.write('Redirecting to Home page...')
        subprocess.Popen(['streamlit', 'run', 'HomePage.py'])
        
    
message()